$(() => {
    $('.icp-auto').iconpicker();
    $('.icp-dd').iconpicker({
    });
    $('.icp').on('iconpickerSelected', function (e) {
    });
});
