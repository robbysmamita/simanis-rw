<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.3.0
    </div>
    <strong> &copy; 2019 <a href="#">Absensi Karyawan</a>.</strong> Template by Admin LTE. | Repost by <a href='https://stokcoding.com/' title='StokCoding.com' target='_blank'>StokCoding.com</a>
	
</footer>
